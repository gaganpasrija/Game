# Project
# I make a small game of rock,paper and sissors with using html , css and javascript.
# output
![Screenshot 2025-05-26 175212](https://github.com/user-attachments/assets/def6b0e6-5483-418a-9620-16dca54e30bb)
